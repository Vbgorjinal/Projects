import React from 'react'

function Games() {
    const lst=['pubg','COC','COD']
  return (
    <div>
      Games:{lst[0]}
    </div>
  )
}

export default Games
