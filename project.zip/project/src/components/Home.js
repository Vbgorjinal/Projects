import React from 'react'
import NavBar from './NavBar'
import Timer from './Useeffect'
import Skill from './Skill'
import Games from './Games'

export default function Home() {
  return (
    <div>
      <NavBar/>
      <Timer/>
      <Skill/>
      <Games/>
    </div>
  )
}
