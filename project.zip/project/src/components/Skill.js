import React, { Component } from 'react'

export default class ChangeTextCasewithTheme extends Component {
    constructor(){
        super();
        this.state={
            text :'',
            theme:'light'
        };
        this.handleChnage=this.handleChnage.bind(this);
        this.changeTextToLowerCase=this.changeTextToLowerCase.bind(this);
        this.changeTextToUpperCase=this.changeTextToUpperCase.bind(this);
        this.toggleTheme=this.toggleTheme.bind(this);
    }
    handleChnage(event){
        this.setState({text:event.target.value});
    }
    changeTextToLowerCase(){
        this.setState({text:this.state.text.toLowerCase()});
    }
    changeTextToUpperCase(){
        this.setState({text:this.state.text.toUpperCase()});
    }
    toggleTheme(){
        this.setState((prevState)=>({
            theme:prevState.theme==='light'?'dark':'light'
        }));
    }
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
