import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import {Browserrouters, Routes, Route} from 'react-router-dom'
import Skill from './components/Skill';
function App() {
  return (
    <div className="App">
      <Browserrouters>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <li href="Skill">Home</li>
          <Route path='/skill' element={<Skill/>}/>
        </Routes>
      </Browserrouters>
    </div>
  );
}

export default App;
